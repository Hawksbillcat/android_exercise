package com.example.kotlinapplication.textClass

import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel
import android.databinding.ObservableField

class MainViewModel : ViewModel() {

        var data = ObservableField<String>("")

        init {
            data.set("init")
        }

        fun buttonClick(){
            data.set("click")
        }

}