package com.example.kotlinapplication.textClass

import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel

class ThirdsData: ViewModel() {

    var num = 0

    val curNum:MutableLiveData<Int> by lazy {
        MutableLiveData<Int>()
    }

    val curBoolean:MutableLiveData<Boolean> by lazy {
        MutableLiveData<Boolean>()
    }

}